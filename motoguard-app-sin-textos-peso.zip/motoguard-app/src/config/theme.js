export const colores = {
  // Paleta MotoGuard (azul noche + turquesa + azul eléctrico)
  fondo: '#0A1220',
  tarjeta: '#121D2D',
  tarjetaSuave: '#0D1624',
  campo: '#060D19',
  borde: '#1F2C40',
  barra: '#0E1724',
  texto: '#F4F7FF',
  textoSuave: '#8F9BB0',
  azul: '#2380FF',
  azulClaro: '#4B9BFF',
  turquesa: '#34D3BC',
  rojoMarca: '#D62828',
  logoFondo: '#F5F9FF',

  // Alertas / estados (sin cambios de significado)
  verde: '#34D3BC',
  rojo: '#F0524F',
  ambar: '#F2A93B',
};

export const espaciado = { xs: 4, s: 8, m: 12, l: 16, xl: 24 };
