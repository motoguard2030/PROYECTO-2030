import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Tarjeta from '../components/Tarjeta';
import Boton from '../components/Boton';
import BiometriaCard from '../components/BiometriaCard';
import PesoPruebaCard from '../components/PesoPruebaCard';
import SinDispositivo from '../components/SinDispositivo';
import TituloPantalla from '../components/TituloPantalla';
import api from '../services';
import { colores } from '../config/theme';

export default function CuentaScreen({
  usuario, codigo, datos, onVincular, onVincularTelegram, onDesvincular, onSalir,
}) {
  return (
    <ScrollView contentContainerStyle={estilos.contenido}>
      <TituloPantalla titulo="Cuenta" />

      <View style={estilos.perfil}>
        <Ionicons name="person-circle-outline" size={56} color={colores.turquesa} />
        <View style={{ flex: 1 }}>
          <Text style={estilos.nombre}>Hola, {usuario.nombre || usuario.email}</Text>
          <Text style={estilos.dispositivo}>Dispositivo: {codigo || '—'}</Text>
        </View>
      </View>

      {!codigo ? (
        <SinDispositivo onVincular={onVincular} />
      ) : (
        <>
          <BiometriaCard
            pesoMin={datos?.peso_min}
            pesoMax={datos?.peso_max}
            puedeGuardar={!!codigo}
            onGuardar={(min, max) => api.guardarRangoPeso(codigo, min, max)}
          />

          <PesoPruebaCard
            pesoMinKg={datos?.peso_min}
            pesoMaxKg={datos?.peso_max}
            pesoActualG={datos?.peso_actual}
            pesoTs={datos?.peso_ts}
            motoEncendida={datos?.moto_encendida}
            estadoPeso={datos?.estado_peso}
            onGuardar={(pesoG, tolG) => api.guardarPesoGramos(codigo, pesoG, tolG)}
            onTarar={() => api.enviarTara(codigo)}
          />

          <Tarjeta titulo="Avisos y dispositivo">
            <Boton titulo="Vincular Telegram" onPress={onVincularTelegram} />
            <Boton titulo="Cambiar o desvincular dispositivo" tipo="secundario"
              onPress={onDesvincular} estilo={{ marginTop: 10 }} />
          </Tarjeta>
        </>
      )}

      <Boton titulo="Salir" tipo="secundario" onPress={onSalir} />
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 32 },
  perfil: {
    flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 16, padding: 18,
    backgroundColor: colores.tarjeta, borderColor: colores.borde, borderWidth: 1, borderRadius: 26,
  },
  nombre: { color: colores.texto, fontSize: 18, fontWeight: '700' },
  dispositivo: { color: colores.textoSuave, fontSize: 14, marginTop: 2 },
});
