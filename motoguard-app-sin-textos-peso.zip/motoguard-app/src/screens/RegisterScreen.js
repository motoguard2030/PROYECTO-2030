import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, Text, View, StyleSheet, KeyboardAvoidingView, Platform, Pressable, Alert } from 'react-native';
import Boton from '../components/Boton';
import CampoTexto from '../components/CampoTexto';
import LogoMarca from '../components/LogoMarca';
import FondoDegradado from '../components/FondoDegradado';
import api from '../services';
import { colores } from '../config/theme';
import { normalizarCodigo } from '../utils/format';

const AYUDA_INICIAL = 'Es el código impreso en tu dispositivo (ej: MG-0007).';

export default function RegisterScreen({ irALogin }) {
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [peso, setPeso] = useState('');
  const [codigo, setCodigo] = useState('');
  const [pin, setPin] = useState('');
  const [ayudaCodigo, setAyudaCodigo] = useState({ mensaje: AYUDA_INICIAL, tono: undefined });
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);
  const verificacion = useRef(0);

  // Validación en vivo: espera 500 ms a que termine de escribir antes de
  // consultar. El número de verificación evita que una respuesta vieja pise
  // a una más nueva.
  useEffect(() => {
    if (!codigo.trim()) {
      setAyudaCodigo({ mensaje: AYUDA_INICIAL, tono: undefined });
      return undefined;
    }
    const miVerificacion = ++verificacion.current;
    const espera = setTimeout(async () => {
      const r = await api.verificarCodigo(normalizarCodigo(codigo));
      if (miVerificacion !== verificacion.current) return;
      const tono = r.estado === 'libre' ? 'ok' : r.estado === 'error' ? undefined : 'error';
      setAyudaCodigo({ mensaje: r.mensaje, tono });
    }, 500);
    return () => clearTimeout(espera);
  }, [codigo]);

  async function registrar() {
    setError('');
    const pesoNumero = parseFloat(peso.replace(',', '.'));
    if (!nombre.trim() || !email.trim() || !password) {
      setError('Completá nombre, correo y contraseña.');
      return;
    }
    if (!Number.isFinite(pesoNumero) || pesoNumero < 30 || pesoNumero > 200) {
      setError('Ingresá un peso válido en kg (ej: 75).');
      return;
    }
    setCargando(true);
    try {
      await api.registrarUsuario({
        nombre: nombre.trim(), email, password, codigo, pin, peso: pesoNumero,
      });
      Alert.alert('¡Listo!', 'Usuario y dispositivo vinculados. Ahora podés iniciar sesión.');
      irALogin();
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  }

  return (
    <View style={estilos.raiz}>
      <FondoDegradado />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={estilos.contenido} keyboardShouldPersistTaps="handled">
          <LogoMarca tamano={96} estilo={{ alignSelf: 'center', marginBottom: 16 }} />
          <Text style={estilos.titulo}>Crear cuenta</Text>

          <View style={estilos.formulario}>
            <CampoTexto etiqueta="Nombre completo" value={nombre} onChangeText={setNombre} autoCapitalize="words" icono="person-outline" />
            <CampoTexto etiqueta="Correo electrónico" value={email} onChangeText={setEmail} keyboardType="email-address" icono="mail-outline" />
            <CampoTexto etiqueta="Contraseña" value={password} onChangeText={setPassword} secureTextEntry icono="lock-closed-outline" />
            <CampoTexto etiqueta="Peso del conductor (kg)" value={peso} onChangeText={setPeso} keyboardType="decimal-pad" placeholder="75" icono="barbell-outline" />
            <CampoTexto etiqueta="Código del dispositivo" value={codigo} onChangeText={setCodigo}
              autoCapitalize="characters" placeholder="MG-0007" icono="hardware-chip-outline"
              ayuda={ayudaCodigo.mensaje} tonoAyuda={ayudaCodigo.tono} />
            <CampoTexto etiqueta="PIN de activación" value={pin} onChangeText={setPin} secureTextEntry keyboardType="number-pad"
              icono="keypad-outline" ayuda="Viene en la etiqueta de tu dispositivo." />

            {!!error && <Text style={estilos.error}>{error}</Text>}
            <Boton titulo="Crear cuenta" onPress={registrar} cargando={cargando} />

            <Pressable onPress={irALogin} style={{ marginTop: 22 }}>
              <Text style={estilos.enlace}>¿Ya tenés cuenta? Iniciá sesión</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const estilos = StyleSheet.create({
  raiz: { flex: 1, backgroundColor: '#050B16' },
  contenido: { flexGrow: 1, padding: 24, paddingTop: 32 },
  titulo: { color: colores.texto, fontSize: 28, fontWeight: '800', textAlign: 'center', marginBottom: 22 },
  formulario: {
    backgroundColor: colores.tarjeta, borderColor: colores.borde, borderWidth: 1, borderRadius: 30, padding: 20, marginBottom: 24,
  },
  error: { color: colores.rojo, marginBottom: 12, fontSize: 13 },
  enlace: { color: colores.turquesa, textAlign: 'center', fontSize: 15, fontWeight: '700', marginBottom: 4 },
});
