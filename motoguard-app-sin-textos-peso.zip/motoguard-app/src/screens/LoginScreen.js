import React, { useState } from 'react';
import { ScrollView, Text, View, StyleSheet, KeyboardAvoidingView, Platform, Pressable } from 'react-native';
import Boton from '../components/Boton';
import CampoTexto from '../components/CampoTexto';
import LogoMarca from '../components/LogoMarca';
import FondoDegradado from '../components/FondoDegradado';
import { useAuth } from '../context/AuthContext';
import { colores } from '../config/theme';

export default function LoginScreen({ irARegistro }) {
  const { iniciarSesion } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  async function ingresar() {
    setError('');
    if (!email.trim() || !password) {
      setError('Completá el correo y la contraseña.');
      return;
    }
    setCargando(true);
    try {
      await iniciarSesion(email, password);
    } catch (e) {
      setError(e.message);
      setCargando(false);
    }
  }

  return (
    <View style={estilos.raiz}>
      <FondoDegradado />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={estilos.contenido} keyboardShouldPersistTaps="handled">
          <LogoMarca tamano={136} estilo={{ alignSelf: 'center' }} />
          <Text style={estilos.lema}>TU MOTO, BAJO CONTROL</Text>
          <Text style={estilos.titulo}>Bienvenido a MotoGuard</Text>
          <Text style={estilos.subtitulo}>Protección inteligente para tu motocicleta.</Text>

          <View style={estilos.formulario}>
            <CampoTexto etiqueta="Correo electrónico" value={email} onChangeText={setEmail}
              keyboardType="email-address" autoComplete="email" placeholder="tu@email.com" icono="mail-outline" />
            <CampoTexto etiqueta="Contraseña" value={password} onChangeText={setPassword}
              secureTextEntry placeholder="Tu contraseña" icono="lock-closed-outline" />

            {!!error && <Text style={estilos.error}>{error}</Text>}
            <Boton titulo="Ingresar" icono="log-in-outline" onPress={ingresar} cargando={cargando} />

            <Pressable onPress={irARegistro} style={{ marginTop: 22 }}>
              <Text style={estilos.enlace}>¿No tenés cuenta? Registrate</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const estilos = StyleSheet.create({
  raiz: { flex: 1, backgroundColor: '#050B16' },
  contenido: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  lema: { color: colores.textoSuave, textAlign: 'center', fontSize: 13, fontWeight: '800', letterSpacing: 3.5, marginTop: 22 },
  titulo: { color: colores.texto, textAlign: 'center', fontSize: 28, fontWeight: '800', marginTop: 34 },
  subtitulo: { color: colores.textoSuave, textAlign: 'center', fontSize: 15, marginTop: 10, marginBottom: 30 },
  formulario: {
    backgroundColor: colores.tarjeta, borderColor: colores.borde, borderWidth: 1, borderRadius: 30, padding: 20,
  },
  error: { color: colores.rojo, marginBottom: 12, fontSize: 13 },
  enlace: { color: colores.turquesa, textAlign: 'center', fontSize: 15, fontWeight: '700', marginBottom: 4 },
});
