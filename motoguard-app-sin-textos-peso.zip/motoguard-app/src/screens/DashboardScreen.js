import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Alert, Linking, Vibration } from 'react-native';
import BarraTabs from '../components/BarraTabs';
import VincularModal from '../components/VincularModal';
import InicioScreen from './InicioScreen';
import UbicacionScreen from './UbicacionScreen';
import AlertasScreen from './AlertasScreen';
import CuentaScreen from './CuentaScreen';
import { useAuth } from '../context/AuthContext';
import { useDispositivo } from '../hooks/useDispositivo';
import { useHistorial } from '../hooks/useHistorial';
import api from '../services';
import { ESTADOS, ESTADOS_PESO } from '../config/constants';
import { urlTelegram } from '../utils/format';

// Cada pestaña queda montada (solo se oculta) para no recargar el mapa ni
// perder lo que se está escribiendo al cambiar de pantalla.
function Pantalla({ activa, children }) {
  return <View style={[estilos.pantalla, !activa && { display: 'none' }]}>{children}</View>;
}

export default function DashboardScreen() {
  const { usuario, cerrarSesion, actualizarUsuario } = useAuth();
  const codigo = usuario.dispositivo;
  const { datos, error } = useDispositivo(codigo);
  const historial = useHistorial(codigo);
  const [modalVincular, setModalVincular] = useState(false);
  const [tab, setTab] = useState('inicio');
  const estadoPrevio = useRef(null);
  const pesoPrevio = useRef(null);

  const estado = datos?.estado ?? ESTADOS.REPOSO;
  const activo = datos?.activo !== false; // si no existe el campo, se asume activo (igual que el firmware)

  // Vibra una vez cuando el estado PASA a confirmado (no al abrir la app).
  useEffect(() => {
    if (!datos) { estadoPrevio.current = null; return; }
    if (estado === ESTADOS.CONFIRMADO && estadoPrevio.current && estadoPrevio.current !== ESTADOS.CONFIRMADO) {
      Vibration.vibrate([0, 500, 200, 500]);
    }
    estadoPrevio.current = estado;
  }, [estado, datos]);

  // Vibra una vez cuando el peso PASA a incorrecto (no al abrir la app).
  const estadoPeso = datos?.estado_peso;
  useEffect(() => {
    if (!datos) { pesoPrevio.current = null; return; }
    const incorrecto = estadoPeso === ESTADOS_PESO.INSUFICIENTE || estadoPeso === ESTADOS_PESO.EXCEDIDO;
    const eraIncorrecto = pesoPrevio.current === ESTADOS_PESO.INSUFICIENTE || pesoPrevio.current === ESTADOS_PESO.EXCEDIDO;
    if (incorrecto && pesoPrevio.current && !eraIncorrecto) {
      Vibration.vibrate([0, 400, 200, 400]);
    }
    pesoPrevio.current = estadoPeso ?? null;
  }, [estadoPeso, datos]);

  async function ejecutar(accion, mensajeOk) {
    try {
      await accion();
      if (mensajeOk) Alert.alert('Listo', mensajeOk);
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  }

  const cambiarActivo = (valor) => ejecutar(() => api.setActivo(codigo, valor));

  const calibrar = () => Alert.alert(
    'Calibrar posición',
    'La moto tiene que estar quieta y en su lugar de estacionamiento. ¿Calibrar ahora?',
    [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Calibrar',
        onPress: () => ejecutar(
          () => api.enviarCalibrar(codigo),
          'Comando enviado. La moto va a recalibrar su posición en los próximos segundos.',
        ),
      },
    ],
  );

  const vincularTelegram = () => Linking.openURL(urlTelegram(codigo)).catch(() =>
    Alert.alert('Error', 'No se pudo abrir Telegram. ¿Está instalado?'));

  const desvincular = () => Alert.alert(
    'Desvincular dispositivo',
    `¿Seguro que querés desvincular ${codigo}? Vas a tener que cargar otro código.`,
    [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Desvincular',
        style: 'destructive',
        onPress: () => ejecutar(async () => {
          await api.desvincularDispositivo(usuario);
          actualizarUsuario({ dispositivo: '' });
        }),
      },
    ],
  );

  const confirmarVinculacion = async (nuevoCodigo, pin) => {
    const codigoNuevo = await api.vincularDispositivo(usuario, nuevoCodigo, pin);
    actualizarUsuario({ dispositivo: codigoNuevo });
  };

  const abrirVincular = () => setModalVincular(true);

  return (
    <View style={estilos.raiz}>
      <View style={estilos.pantalla}>
        <Pantalla activa={tab === 'inicio'}>
          <InicioScreen
            codigo={codigo} datos={datos} error={error} estado={estado} activo={activo}
            onCambiarActivo={cambiarActivo} onCalibrar={calibrar} onVincular={abrirVincular}
          />
        </Pantalla>
        <Pantalla activa={tab === 'ubicacion'}>
          <UbicacionScreen codigo={codigo} datos={datos} onVincular={abrirVincular} />
        </Pantalla>
        <Pantalla activa={tab === 'alertas'}>
          <AlertasScreen codigo={codigo} datos={datos} estado={estado} historial={historial} onVincular={abrirVincular} />
        </Pantalla>
        <Pantalla activa={tab === 'cuenta'}>
          <CuentaScreen
            usuario={usuario} codigo={codigo} datos={datos} onVincular={abrirVincular}
            onVincularTelegram={vincularTelegram} onDesvincular={desvincular} onSalir={cerrarSesion}
          />
        </Pantalla>
      </View>

      <BarraTabs activa={tab} onCambiar={setTab} />

      <VincularModal
        visible={modalVincular}
        onCerrar={() => setModalVincular(false)}
        onConfirmar={confirmarVinculacion}
      />
    </View>
  );
}

const estilos = StyleSheet.create({
  raiz: { flex: 1 },
  pantalla: { flex: 1 },
});
