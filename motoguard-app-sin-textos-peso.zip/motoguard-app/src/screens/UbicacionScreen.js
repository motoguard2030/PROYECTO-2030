import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import MapaCard from '../components/MapaCard';
import SinDispositivo from '../components/SinDispositivo';
import TituloPantalla from '../components/TituloPantalla';

export default function UbicacionScreen({ codigo, datos, onVincular }) {
  return (
    <ScrollView contentContainerStyle={estilos.contenido}>
      <TituloPantalla titulo="Ubicación" detalle="Dónde está tu moto ahora" />
      {!codigo ? (
        <SinDispositivo onVincular={onVincular} />
      ) : (
        <MapaCard lat={datos?.lat} lng={datos?.lng} alto={440} />
      )}
    </ScrollView>
  );
}

const estilos = StyleSheet.create({ contenido: { padding: 18, paddingBottom: 32 } });
