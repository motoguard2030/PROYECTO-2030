import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import AlertaBanner from '../components/AlertaBanner';
import PesoBanner from '../components/PesoBanner';
import HistorialCard from '../components/HistorialCard';
import SinDispositivo from '../components/SinDispositivo';
import TituloPantalla from '../components/TituloPantalla';

export default function AlertasScreen({ codigo, datos, estado, historial, onVincular }) {
  return (
    <ScrollView contentContainerStyle={estilos.contenido}>
      <TituloPantalla titulo="Alertas" detalle="Avisos y eventos de tu moto" />
      {!codigo ? (
        <SinDispositivo onVincular={onVincular} />
      ) : (
        <>
          <AlertaBanner estado={estado} />
          <PesoBanner estadoPeso={datos?.estado_peso} pesoActualG={datos?.peso_actual} />
          <HistorialCard eventos={historial} />
        </>
      )}
    </ScrollView>
  );
}

const estilos = StyleSheet.create({ contenido: { padding: 18, paddingBottom: 32 } });
