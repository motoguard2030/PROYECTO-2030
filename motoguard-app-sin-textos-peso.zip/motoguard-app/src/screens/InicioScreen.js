import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Tarjeta from '../components/Tarjeta';
import Boton from '../components/Boton';
import LogoMarca from '../components/LogoMarca';
import AlertaBanner from '../components/AlertaBanner';
import PesoBanner from '../components/PesoBanner';
import SinDispositivo from '../components/SinDispositivo';
import { colores } from '../config/theme';
import { ESTADOS } from '../config/constants';
import { esNumero } from '../utils/format';

const TEXTO_ESTADO = {
  [ESTADOS.REPOSO]: { texto: 'REPOSO', color: colores.turquesa, icono: 'shield-checkmark-outline' },
  [ESTADOS.ALERTA]: { texto: 'MOVIMIENTO', color: colores.ambar, icono: 'warning-outline' },
  [ESTADOS.CONFIRMADO]: { texto: '¡ALERTA!', color: colores.rojo, icono: 'alert-circle-outline' },
};

function Dato({ icono, etiqueta, valor }) {
  return (
    <View style={estilos.dato}>
      <Ionicons name={icono} size={22} color={colores.turquesa} />
      <Text style={estilos.datoEtiqueta}>{etiqueta}</Text>
      <Text style={estilos.datoValor}>{valor}</Text>
    </View>
  );
}

export default function InicioScreen({
  codigo, datos, error, estado, activo, onCambiarActivo, onCalibrar, onVincular,
}) {
  const info = TEXTO_ESTADO[estado] ?? TEXTO_ESTADO[ESTADOS.REPOSO];
  const hayGps = esNumero(datos?.lat) && esNumero(datos?.lng);

  return (
    <ScrollView contentContainerStyle={estilos.contenido}>
      <View style={estilos.cabecera}>
        <LogoMarca tamano={64} />
        <View style={{ flex: 1 }}>
          <Text style={estilos.marca}>MOTOGUARD</Text>
          <Text style={estilos.marcaDetalle}>Estado de tu dispositivo</Text>
        </View>
        <View style={[estilos.sello, { backgroundColor: info.color + '26' }]}>
          <Ionicons name="shield-checkmark" size={22} color={info.color} />
        </View>
      </View>

      <Text style={estilos.titulo}>Panel de seguridad</Text>

      {!codigo ? (
        <SinDispositivo onVincular={onVincular} />
      ) : (
        <>
          <AlertaBanner estado={estado} />
          <PesoBanner estadoPeso={datos?.estado_peso} pesoActualG={datos?.peso_actual} />
          {!!error && <Text style={estilos.error}>No se pudo leer el dispositivo: {error.message}</Text>}

          <View style={estilos.estadoCaja}>
            <View style={[estilos.estadoIcono, { backgroundColor: info.color + '26' }]}>
              <Ionicons name={info.icono} size={42} color={info.color} />
            </View>
            <Text style={[estilos.estadoEtiqueta, { color: info.color }]}>ESTADO DEL SISTEMA</Text>
            <Text style={estilos.estadoValor}>{info.texto}</Text>
            <Text style={estilos.estadoDispositivo}>Dispositivo: {codigo}</Text>

            <View style={estilos.datos}>
              <Dato icono="pulse-outline" etiqueta="Sensores" valor={datos ? 'Con datos' : 'Sin datos'} />
              <Dato icono="location-outline" etiqueta="GPS" valor={hayGps ? 'Con ubicación' : 'Sin ubicación'} />
            </View>
          </View>

          <Tarjeta titulo="Control del sistema">
            <Text style={estilos.suave}>
              Sistema: <Text style={{ color: activo ? colores.verde : colores.rojo, fontWeight: '700' }}>
                {activo ? 'Activado' : 'Desactivado'}
              </Text>
            </Text>
            <View style={estilos.fila}>
              <Boton titulo="Desactivar" tipo="peligro" onPress={() => onCambiarActivo(false)}
                deshabilitado={!activo} estilo={{ flex: 1 }} />
              <Boton titulo="Activar" onPress={() => onCambiarActivo(true)}
                deshabilitado={activo} estilo={{ flex: 1 }} />
            </View>
            <Boton titulo="Calibrar posición de estacionamiento" tipo="secundario"
              onPress={onCalibrar} estilo={{ marginTop: 10 }} />
          </Tarjeta>
        </>
      )}
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 32 },
  cabecera: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 22 },
  marca: { color: colores.texto, fontSize: 22, fontWeight: '800', letterSpacing: 2 },
  marcaDetalle: { color: colores.textoSuave, fontSize: 14, marginTop: 2 },
  sello: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  titulo: { color: colores.texto, fontSize: 26, fontWeight: '800', marginBottom: 16 },
  estadoCaja: {
    backgroundColor: colores.tarjeta, borderColor: colores.borde, borderWidth: 1, borderRadius: 32,
    padding: 22, alignItems: 'center', marginBottom: 16,
  },
  estadoIcono: { width: 76, height: 76, borderRadius: 24, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  estadoEtiqueta: { fontSize: 14, fontWeight: '800', letterSpacing: 2.5 },
  estadoValor: { color: colores.texto, fontSize: 36, fontWeight: '800', marginTop: 6 },
  estadoDispositivo: { color: colores.textoSuave, fontSize: 15, marginTop: 6 },
  datos: { flexDirection: 'row', gap: 12, marginTop: 22, alignSelf: 'stretch' },
  dato: { flex: 1, backgroundColor: colores.tarjetaSuave, borderRadius: 20, padding: 14, gap: 4 },
  datoEtiqueta: { color: colores.textoSuave, fontSize: 14, marginTop: 4 },
  datoValor: { color: colores.texto, fontSize: 17, fontWeight: '800' },
  suave: { color: colores.textoSuave, fontSize: 14, marginBottom: 12 },
  fila: { flexDirection: 'row', gap: 10 },
  error: { color: colores.rojo, marginBottom: 12, fontSize: 13 },
});
