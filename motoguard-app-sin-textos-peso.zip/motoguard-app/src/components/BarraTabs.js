import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colores } from '../config/theme';

export const TABS = [
  { id: 'inicio', titulo: 'Inicio', icono: 'shield-checkmark-outline', iconoActivo: 'shield-checkmark' },
  { id: 'ubicacion', titulo: 'Ubicación', icono: 'location-outline', iconoActivo: 'location' },
  { id: 'alertas', titulo: 'Alertas', icono: 'notifications-outline', iconoActivo: 'notifications' },
  { id: 'cuenta', titulo: 'Cuenta', icono: 'person-circle-outline', iconoActivo: 'person-circle' },
];

export default function BarraTabs({ activa, onCambiar }) {
  return (
    <View style={estilos.barra}>
      {TABS.map((tab) => {
        const seleccionada = tab.id === activa;
        const color = seleccionada ? colores.turquesa : colores.textoSuave;
        return (
          <Pressable key={tab.id} style={estilos.tab} onPress={() => onCambiar(tab.id)} accessibilityRole="tab"
            accessibilityState={{ selected: seleccionada }}>
            <Ionicons name={seleccionada ? tab.iconoActivo : tab.icono} size={28} color={color} />
            <Text style={[estilos.titulo, { color }]}>{tab.titulo}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const estilos = StyleSheet.create({
  barra: {
    flexDirection: 'row',
    backgroundColor: colores.barra,
    borderTopWidth: 1,
    borderTopColor: colores.borde,
    paddingTop: 10,
    paddingBottom: 8,
  },
  tab: { flex: 1, alignItems: 'center', gap: 4 },
  titulo: { fontSize: 13, fontWeight: '700' },
});
