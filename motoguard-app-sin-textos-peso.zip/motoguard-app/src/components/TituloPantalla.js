import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colores } from '../config/theme';

export default function TituloPantalla({ titulo, detalle }) {
  return (
    <View style={estilos.caja}>
      <Text style={estilos.titulo}>{titulo}</Text>
      {!!detalle && <Text style={estilos.detalle}>{detalle}</Text>}
    </View>
  );
}

const estilos = StyleSheet.create({
  caja: { marginBottom: 16 },
  titulo: { color: colores.texto, fontSize: 26, fontWeight: '800' },
  detalle: { color: colores.textoSuave, fontSize: 14, marginTop: 4 },
});
