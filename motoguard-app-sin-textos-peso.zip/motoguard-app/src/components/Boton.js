import React from 'react';
import { Pressable, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colores } from '../config/theme';

const FONDOS = {
  primario: colores.azul,
  peligro: colores.rojo,
  secundario: 'transparent',
};

export default function Boton({ titulo, onPress, tipo = 'primario', deshabilitado, cargando, estilo, icono }) {
  const inactivo = deshabilitado || cargando;
  return (
    <Pressable
      onPress={onPress}
      disabled={inactivo}
      style={({ pressed }) => [
        estilos.base,
        { backgroundColor: FONDOS[tipo] },
        tipo === 'secundario' && estilos.borde,
        (pressed || inactivo) && { opacity: 0.6 },
        estilo,
      ]}
    >
      {cargando ? (
        <ActivityIndicator color={colores.texto} />
      ) : (
        <>
          {!!icono && <Ionicons name={icono} size={22} color={colores.texto} style={{ marginRight: 10 }} />}
          <Text style={estilos.texto}>{titulo}</Text>
        </>
      )}
    </Pressable>
  );
}

const estilos = StyleSheet.create({
  base: { minHeight: 54, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  borde: { borderWidth: 1, borderColor: colores.borde },
  texto: { color: colores.texto, fontWeight: '700', fontSize: 16, textAlign: 'center' },
});
