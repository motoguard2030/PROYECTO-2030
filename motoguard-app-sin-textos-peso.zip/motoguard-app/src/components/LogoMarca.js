import React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { colores } from '../config/theme';

// Logo dentro de su cuadrado blanco con esquinas redondeadas.
export default function LogoMarca({ tamano = 64, estilo }) {
  return (
    <View
      style={[
        estilos.caja,
        { width: tamano, height: tamano, borderRadius: tamano * 0.29, padding: tamano * 0.08 },
        estilo,
      ]}
    >
      <Image source={require('../../assets/logo.png')} style={{ width: '100%', height: '100%' }} resizeMode="contain" />
    </View>
  );
}

const estilos = StyleSheet.create({
  caja: { backgroundColor: colores.logoFondo, alignItems: 'center', justifyContent: 'center' },
});
