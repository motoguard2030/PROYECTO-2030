import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ESTADOS_PESO } from '../config/constants';
import { colores } from '../config/theme';
import { esNumero } from '../utils/format';

// Cartel de color según el estado_peso que publica el ESP32 (sin textos de estado):
//   AUTORIZADO                 -> verde
//   PESO_INSUFICIENTE/EXCEDIDO -> rojo
//   BALANZA_ERROR              -> ámbar
// Con asiento vacío, sin rango o iniciando no se muestra nada.
export default function PesoBanner({ estadoPeso, pesoActualG }) {
  const peso = esNumero(pesoActualG) ? `${pesoActualG.toFixed(1)} g` : '—';

  let color = null;
  if (estadoPeso === ESTADOS_PESO.AUTORIZADO) color = colores.verde;
  else if (estadoPeso === ESTADOS_PESO.INSUFICIENTE || estadoPeso === ESTADOS_PESO.EXCEDIDO) color = colores.rojo;
  else if (estadoPeso === ESTADOS_PESO.BALANZA_ERROR) color = colores.ambar;
  if (!color) return null;

  return (
    <View style={[estilos.caja, { backgroundColor: color }]}>
      <Text style={estilos.texto}>Peso medido: {peso}</Text>
    </View>
  );
}

const estilos = StyleSheet.create({
  caja: { borderRadius: 20, padding: 16, marginBottom: 16 },
  texto: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
