import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colores } from '../config/theme';

// `ayuda` es un texto chico debajo del campo; `tonoAyuda` = 'ok' | 'error' | undefined.
// `icono` es el nombre de un icono Ionicons a la izquierda. En campos de
// contraseña se agrega el ojito para mostrar/ocultar.
export default function CampoTexto({ etiqueta, ayuda, tonoAyuda, icono, ...resto }) {
  const [visible, setVisible] = useState(false);
  const esClave = !!resto.secureTextEntry;
  const colorAyuda = tonoAyuda === 'ok' ? colores.verde : tonoAyuda === 'error' ? colores.rojo : colores.textoSuave;
  return (
    <View style={estilos.contenedor}>
      <Text style={estilos.etiqueta}>{etiqueta}</Text>
      <View
        style={[
          estilos.campo,
          tonoAyuda === 'error' && { borderColor: colores.rojo },
          tonoAyuda === 'ok' && { borderColor: colores.verde },
        ]}
      >
        {!!icono && <Ionicons name={icono} size={24} color={colores.textoSuave} style={{ marginRight: 12 }} />}
        <TextInput
          placeholderTextColor={colores.textoSuave}
          autoCapitalize="none"
          style={estilos.input}
          {...resto}
          secureTextEntry={esClave && !visible}
        />
        {esClave && (
          <Pressable onPress={() => setVisible((v) => !v)} hitSlop={10}>
            <Ionicons name={visible ? 'eye-off-outline' : 'eye-outline'} size={24} color={colores.textoSuave} />
          </Pressable>
        )}
      </View>
      {!!ayuda && <Text style={[estilos.ayuda, { color: colorAyuda }]}>{ayuda}</Text>}
    </View>
  );
}

const estilos = StyleSheet.create({
  contenedor: { marginBottom: 16 },
  etiqueta: { color: colores.texto, fontSize: 15, fontWeight: '700', marginBottom: 8 },
  campo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colores.campo,
    borderColor: colores.borde,
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 16,
    minHeight: 54,
  },
  input: { flex: 1, color: colores.texto, fontSize: 16, paddingVertical: 12 },
  ayuda: { fontSize: 12, marginTop: 6 },
});
