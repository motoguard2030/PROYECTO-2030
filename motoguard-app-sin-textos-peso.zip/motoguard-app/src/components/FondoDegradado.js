import React from 'react';
import { View, StyleSheet } from 'react-native';

// Degradado azul noche -> negro hecho con franjas (no necesita librerías extra).
const FRANJAS = 28;
const ALTO_FRANJA = 24;

export default function FondoDegradado() {
  return (
    <View pointerEvents="none" style={estilos.contenedor}>
      {Array.from({ length: FRANJAS }, (_, i) => (
        <View
          key={i}
          style={{ height: ALTO_FRANJA, backgroundColor: '#0E2A55', opacity: 0.55 * (1 - i / FRANJAS) }}
        />
      ))}
    </View>
  );
}

const estilos = StyleSheet.create({ contenedor: { position: 'absolute', top: 0, left: 0, right: 0 } });
