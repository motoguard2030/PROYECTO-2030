import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Slider from '@react-native-community/slider';
import Tarjeta from './Tarjeta';
import { colores } from '../config/theme';
import { PESO } from '../config/constants';
import { esNumero, redondear1 } from '../utils/format';

// Peso autorizado ± tolerancia. Los textos se actualizan al instante y se
// guarda 400 ms después de soltar/mover el slider (no un pedido por cada pixel).
export default function BiometriaCard({ pesoMin, pesoMax, puedeGuardar, onGuardar }) {
  const [peso, setPeso] = useState(75);
  const [tolerancia, setTolerancia] = useState(3);
  const [mensaje, setMensaje] = useState('');
  const [esError, setEsError] = useState(false);
  const moviendo = useRef(false);
  const temporizador = useRef(null);

  // Trae el valor guardado, salvo que el usuario esté moviendo un slider.
  useEffect(() => {
    if (moviendo.current) return;
    if (esNumero(pesoMin) && esNumero(pesoMax)) {
      setPeso((pesoMin + pesoMax) / 2);
      setTolerancia((pesoMax - pesoMin) / 2);
    }
  }, [pesoMin, pesoMax]);

  useEffect(() => () => clearTimeout(temporizador.current), []);

  function programarGuardado(nuevoPeso, nuevaTol) {
    if (!puedeGuardar) {
      setEsError(true);
      setMensaje('Vinculá un dispositivo para poder guardar este rango.');
      return;
    }
    setEsError(false);
    setMensaje('Guardando...');
    clearTimeout(temporizador.current);
    temporizador.current = setTimeout(async () => {
      try {
        await onGuardar(redondear1(nuevoPeso - nuevaTol), redondear1(nuevoPeso + nuevaTol));
        setMensaje('✓ Rango guardado en tu dispositivo.');
      } catch (e) {
        setEsError(true);
        setMensaje(`No se pudo guardar: ${e.message}`);
      }
    }, 400);
  }

  const cambiarPeso = (v) => { setPeso(v); programarGuardado(v, tolerancia); };
  const cambiarTol = (v) => { setTolerancia(v); programarGuardado(peso, v); };
  const empezar = () => { moviendo.current = true; };
  const terminar = () => { moviendo.current = false; };

  return (
    <Tarjeta titulo="Validación biométrica">
      <Text style={estilos.etiqueta}>Peso autorizado: <Text style={estilos.valor}>{peso} kg</Text></Text>
      <Slider
        minimumValue={PESO.min} maximumValue={PESO.max} step={PESO.paso} value={peso}
        onValueChange={cambiarPeso} onSlidingStart={empezar} onSlidingComplete={terminar}
        minimumTrackTintColor={colores.azulClaro} thumbTintColor={colores.azulClaro}
      />
      <Text style={estilos.etiqueta}>Tolerancia (±): <Text style={estilos.valor}>{tolerancia} kg</Text></Text>
      <Slider
        minimumValue={PESO.tolMin} maximumValue={PESO.tolMax} step={PESO.paso} value={tolerancia}
        onValueChange={cambiarTol} onSlidingStart={empezar} onSlidingComplete={terminar}
        minimumTrackTintColor={colores.azulClaro} thumbTintColor={colores.azulClaro}
      />
      <View style={estilos.rango}>
        <Text style={estilos.etiqueta}>Rango aceptado por el sensor</Text>
        <Text style={estilos.rangoValor}>{(peso - tolerancia).toFixed(1)} kg – {(peso + tolerancia).toFixed(1)} kg</Text>
      </View>
      {!!mensaje && (
        <Text style={[estilos.mensaje, { color: esError ? colores.rojo : colores.textoSuave }]}>{mensaje}</Text>
      )}
    </Tarjeta>
  );
}

const estilos = StyleSheet.create({
  etiqueta: { color: colores.textoSuave, fontSize: 13, marginTop: 6 },
  valor: { color: colores.texto, fontWeight: '700' },
  rango: { marginTop: 14, padding: 14, backgroundColor: colores.tarjetaSuave, borderRadius: 18 },
  rangoValor: { color: colores.azulClaro, fontSize: 18, fontWeight: '700', marginTop: 4 },
  mensaje: { fontSize: 12, marginTop: 10 },
});
