import React from 'react';
import { Text, StyleSheet } from 'react-native';
import Tarjeta from './Tarjeta';
import Boton from './Boton';
import { colores } from '../config/theme';

export default function SinDispositivo({ onVincular }) {
  return (
    <Tarjeta titulo="Sin dispositivo">
      <Text style={estilos.suave}>Tu cuenta no tiene ninguna moto vinculada.</Text>
      <Boton titulo="Vincular dispositivo" onPress={onVincular} estilo={{ marginTop: 12 }} />
    </Tarjeta>
  );
}

const estilos = StyleSheet.create({ suave: { color: colores.textoSuave, fontSize: 14, marginBottom: 12 } });
