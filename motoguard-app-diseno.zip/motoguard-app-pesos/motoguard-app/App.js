import React, { useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import { colores } from './src/config/theme';

// Sin librería de navegación: son solo 3 pantallas y se elige según la sesión.
function Raiz() {
  const { usuario, cargando } = useAuth();
  const [pantalla, setPantalla] = useState('login'); // 'login' | 'registro'

  if (cargando) {
    return (
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <ActivityIndicator size="large" color={colores.azulClaro} />
      </View>
    );
  }
  if (usuario) return <DashboardScreen />;
  if (pantalla === 'registro') return <RegisterScreen irALogin={() => setPantalla('login')} />;
  return <LoginScreen irARegistro={() => setPantalla('registro')} />;
}

export default function App() {
  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: colores.fondo }}>
        <StatusBar style="light" />
        <AuthProvider>
          <Raiz />
        </AuthProvider>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
