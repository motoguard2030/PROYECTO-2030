// Configuración central de MotoGuard. Si algo cambia (rutas, bot, rangos),
// se cambia acá y no en cada pantalla.

// 'firebase' = datos reales | 'mock' = datos simulados (sirve para ensayar
// la presentación sin hardware ni internet).
export const BACKEND = 'firebase';

// Todas las rutas de Firebase cuelgan de esta raíz (igual que la web).
export const RAIZ = 'MotoGuard';

export const TELEGRAM_BOT = 'motoguard_alert_bot';

export const REGEX_CODIGO = /^MG-\d{4}$/;

export const ESTADOS = {
  REPOSO: 'REPOSO',
  ALERTA: 'ALERTA',
  CONFIRMADO: 'MOVIMIENTO_CONFIRMADO',
};

// Corrientes/Resistencia, hasta que llegue el primer dato del GPS.
export const POSICION_POR_DEFECTO = { lat: -27.4606, lng: -58.9869 };

export const PESO = { min: 40, max: 150, tolMin: 1, tolMax: 10, paso: 0.5 };

export const HISTORIAL_MAXIMO = 10;

// Prueba con la celda de carga (HX711, 20 kg). Valores en GRAMOS.
export const PESO_PRUEBA = { porDefecto: 200, tolerancia: 10, max: 20000, tolMin: 5 };

// Resultado que publica el ESP32 en estado_peso.
export const ESTADOS_PESO = {
  AUTORIZADO: 'AUTORIZADO',
  INSUFICIENTE: 'PESO_INSUFICIENTE',
  EXCEDIDO: 'PESO_EXCEDIDO',
  SIN_REGISTRO: 'SIN_REGISTRO',
  ASIENTO_VACIO: 'ASIENTO_VACIO',
  BALANZA_ERROR: 'BALANZA_ERROR',
  INICIANDO: 'INICIANDO',
};

// Evento que el ESP32 guarda en el historial cuando el peso no es el autorizado.
export const EVENTO_PESO_INCORRECTO = 'PESO_INCORRECTO';

// Si peso_ts (hora del servidor) tiene más de esto, se avisa "sin lecturas nuevas".
export const PESO_SIN_DATOS_MS = 15000;
