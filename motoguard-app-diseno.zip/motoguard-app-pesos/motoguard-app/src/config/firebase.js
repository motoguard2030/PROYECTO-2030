import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// Mismos datos del proyecto que usa la web (son identificadores públicos del
// cliente; lo que protege la base son las REGLAS de Firebase).
const firebaseConfig = {
  apiKey: 'AIzaSyAFZZ4jWRt9_Bz6at_IDdYXhbQdk2X-_S0',
  authDomain: 'motoguard-45eeb.firebaseapp.com',
  databaseURL: 'https://motoguard-45eeb-default-rtdb.firebaseio.com',
  projectId: 'motoguard-45eeb',
  storageBucket: 'motoguard-45eeb.firebasestorage.app',
  messagingSenderId: '299538184708',
  appId: '1:299538184708:web:a84aa4b1f66d2184155351',
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

export const db = getDatabase(app);
