export const colores = {
  // Marca MotoGuard: negro, azul y rojo
  fondo: '#0A0A0C',
  tarjeta: '#151519',
  borde: '#262A36',
  texto: '#F2F4F8',
  textoSuave: '#9AA3B2',
  azul: '#1F4FBF',
  azulClaro: '#4A7CFF',
  rojoMarca: '#D62828',

  // Alertas / estados (sin cambios de significado)
  verde: '#1D9E75',
  rojo: '#E24B4A',
  ambar: '#E0A03A',
};

export const espaciado = { xs: 4, s: 8, m: 12, l: 16, xl: 24 };
