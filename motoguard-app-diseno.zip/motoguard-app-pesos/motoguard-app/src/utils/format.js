import { TELEGRAM_BOT } from '../config/constants';

// Firebase no admite "." en las claves: el correo se guarda con "_" en su lugar
// (igual que la web y la app de App Inventor).
export const claveDeEmail = (email) => email.trim().replace(/\./g, '_');

export const normalizarCodigo = (texto) => texto.trim().toUpperCase();

export const esNumero = (valor) => typeof valor === 'number' && Number.isFinite(valor);

export function formatearFecha(timestamp) {
  if (!timestamp) return 'Fecha desconocida';
  return new Date(timestamp).toLocaleString('es-AR');
}

export const redondear1 = (n) => Math.round(n * 10) / 10;

// La app guarda el peso en KILOS (peso_min / peso_max). Para la prueba con la
// celda de carga se trabaja en gramos: 200 g -> 0.2 kg (precision de 0.1 g).
export const gramosAKg = (g) => Math.round(g * 10) / 10000;
export const kgAGramos = (kg) => Math.round(kg * 10000) / 10;

// Telegram no permite "-" en el parámetro ?start=, por eso MG-0002 -> MG_0002
// (n8n lo vuelve a convertir del otro lado).
export const urlTelegram = (codigo) =>
  `https://t.me/${TELEGRAM_BOT}?start=${codigo.replace(/-/g, '_')}`;
