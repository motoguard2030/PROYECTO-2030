import AsyncStorage from '@react-native-async-storage/async-storage';

const CLAVE = 'motoguard_sesion';

// Solo se guarda la clave del usuario (correo sanitizado), nunca la contraseña.
export async function guardarSesion(claveUsuario) {
  try { await AsyncStorage.setItem(CLAVE, claveUsuario); } catch (e) { /* sin sesión persistente */ }
}

export async function leerSesion() {
  try { return await AsyncStorage.getItem(CLAVE); } catch (e) { return null; }
}

export async function borrarSesion() {
  try { await AsyncStorage.removeItem(CLAVE); } catch (e) { /* nada */ }
}
