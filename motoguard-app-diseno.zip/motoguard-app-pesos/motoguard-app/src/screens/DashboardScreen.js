import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, View, Text, Image, StyleSheet, Alert, Linking, Vibration } from 'react-native';
import Tarjeta from '../components/Tarjeta';
import Boton from '../components/Boton';
import AlertaBanner from '../components/AlertaBanner';
import PesoBanner from '../components/PesoBanner';
import MapaCard from '../components/MapaCard';
import BiometriaCard from '../components/BiometriaCard';
import PesoPruebaCard from '../components/PesoPruebaCard';
import HistorialCard from '../components/HistorialCard';
import VincularModal from '../components/VincularModal';
import { useAuth } from '../context/AuthContext';
import { useDispositivo } from '../hooks/useDispositivo';
import { useHistorial } from '../hooks/useHistorial';
import api from '../services';
import { colores } from '../config/theme';
import { ESTADOS, ESTADOS_PESO } from '../config/constants';
import { urlTelegram } from '../utils/format';

const TEXTO_ESTADO = {
  [ESTADOS.REPOSO]: { texto: 'Todo normal', color: colores.verde },
  [ESTADOS.ALERTA]: { texto: 'Movimiento detectado', color: colores.ambar },
  [ESTADOS.CONFIRMADO]: { texto: '¡Alerta!', color: colores.rojo },
};

export default function DashboardScreen() {
  const { usuario, cerrarSesion, actualizarUsuario } = useAuth();
  const codigo = usuario.dispositivo;
  const { datos, error } = useDispositivo(codigo);
  const historial = useHistorial(codigo);
  const [modalVincular, setModalVincular] = useState(false);
  const estadoPrevio = useRef(null);
  const pesoPrevio = useRef(null);

  const estado = datos?.estado ?? ESTADOS.REPOSO;
  const activo = datos?.activo !== false; // si no existe el campo, se asume activo (igual que el firmware)
  const info = TEXTO_ESTADO[estado] ?? TEXTO_ESTADO[ESTADOS.REPOSO];

  // Vibra una vez cuando el estado PASA a confirmado (no al abrir la app).
  useEffect(() => {
    if (!datos) { estadoPrevio.current = null; return; }
    if (estado === ESTADOS.CONFIRMADO && estadoPrevio.current && estadoPrevio.current !== ESTADOS.CONFIRMADO) {
      Vibration.vibrate([0, 500, 200, 500]);
    }
    estadoPrevio.current = estado;
  }, [estado, datos]);

  // Vibra una vez cuando el peso PASA a incorrecto (no al abrir la app).
  const estadoPeso = datos?.estado_peso;
  useEffect(() => {
    if (!datos) { pesoPrevio.current = null; return; }
    const incorrecto = estadoPeso === ESTADOS_PESO.INSUFICIENTE || estadoPeso === ESTADOS_PESO.EXCEDIDO;
    const eraIncorrecto = pesoPrevio.current === ESTADOS_PESO.INSUFICIENTE || pesoPrevio.current === ESTADOS_PESO.EXCEDIDO;
    if (incorrecto && pesoPrevio.current && !eraIncorrecto) {
      Vibration.vibrate([0, 400, 200, 400]);
    }
    pesoPrevio.current = estadoPeso ?? null;
  }, [estadoPeso, datos]);

  async function ejecutar(accion, mensajeOk) {
    try {
      await accion();
      if (mensajeOk) Alert.alert('Listo', mensajeOk);
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  }

  const cambiarActivo = (valor) => ejecutar(() => api.setActivo(codigo, valor));

  const calibrar = () => Alert.alert(
    'Calibrar posición',
    'La moto tiene que estar quieta y en su lugar de estacionamiento. ¿Calibrar ahora?',
    [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Calibrar',
        onPress: () => ejecutar(
          () => api.enviarCalibrar(codigo),
          'Comando enviado. La moto va a recalibrar su posición en los próximos segundos.',
        ),
      },
    ],
  );

  const vincularTelegram = () => Linking.openURL(urlTelegram(codigo)).catch(() =>
    Alert.alert('Error', 'No se pudo abrir Telegram. ¿Está instalado?'));

  const desvincular = () => Alert.alert(
    'Desvincular dispositivo',
    `¿Seguro que querés desvincular ${codigo}? Vas a tener que cargar otro código.`,
    [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Desvincular',
        style: 'destructive',
        onPress: () => ejecutar(async () => {
          await api.desvincularDispositivo(usuario);
          actualizarUsuario({ dispositivo: '' });
        }),
      },
    ],
  );

  const confirmarVinculacion = async (nuevoCodigo, pin) => {
    const codigoNuevo = await api.vincularDispositivo(usuario, nuevoCodigo, pin);
    actualizarUsuario({ dispositivo: codigoNuevo });
  };

  return (
    <ScrollView contentContainerStyle={estilos.contenido}>
      <View style={estilos.cabecera}>
        <View style={estilos.logoCaja}>
          <Image source={require('../../assets/logo.png')} style={estilos.logo} resizeMode="contain" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={estilos.saludo}>Hola, {usuario.nombre || usuario.email}</Text>
          <Text style={estilos.dispositivo}>Dispositivo: {codigo || '—'}</Text>
        </View>
        <Boton titulo="Salir" tipo="secundario" onPress={cerrarSesion} />
      </View>

      {!codigo ? (
        <Tarjeta titulo="Sin dispositivo">
          <Text style={estilos.suave}>Tu cuenta no tiene ninguna moto vinculada.</Text>
          <Boton titulo="Vincular dispositivo" onPress={() => setModalVincular(true)} estilo={{ marginTop: 12 }} />
        </Tarjeta>
      ) : (
        <>
          <AlertaBanner estado={estado} />
          <PesoBanner estadoPeso={datos?.estado_peso} pesoActualG={datos?.peso_actual} />
          {!!error && <Text style={estilos.error}>No se pudo leer el dispositivo: {error.message}</Text>}

          <Tarjeta
            titulo="Estado del sistema"
            derecha={<Text style={[estilos.insignia, { backgroundColor: info.color }]}>{info.texto}</Text>}
          >
            <Text style={estilos.suave}>
              Sistema: <Text style={{ color: activo ? colores.verde : colores.rojo, fontWeight: '700' }}>
                {activo ? 'Activado' : 'Desactivado'}
              </Text>
            </Text>
            <View style={estilos.fila}>
              <Boton titulo="Desactivar" tipo="peligro" onPress={() => cambiarActivo(false)}
                deshabilitado={!activo} estilo={{ flex: 1 }} />
              <Boton titulo="Activar" onPress={() => cambiarActivo(true)}
                deshabilitado={activo} estilo={{ flex: 1 }} />
            </View>
            <Boton titulo="Calibrar posición de estacionamiento" tipo="secundario"
              onPress={calibrar} estilo={{ marginTop: 10 }} />
          </Tarjeta>

          <MapaCard lat={datos?.lat} lng={datos?.lng} />

          <BiometriaCard
            pesoMin={datos?.peso_min}
            pesoMax={datos?.peso_max}
            puedeGuardar={!!codigo}
            onGuardar={(min, max) => api.guardarRangoPeso(codigo, min, max)}
          />

          <PesoPruebaCard
            pesoMinKg={datos?.peso_min}
            pesoMaxKg={datos?.peso_max}
            pesoActualG={datos?.peso_actual}
            pesoTs={datos?.peso_ts}
            motoEncendida={datos?.moto_encendida}
            estadoPeso={datos?.estado_peso}
            onGuardar={(pesoG, tolG) => api.guardarPesoGramos(codigo, pesoG, tolG)}
            onTarar={() => api.enviarTara(codigo)}
          />

          <HistorialCard eventos={historial} />

          <Tarjeta titulo="Avisos y dispositivo">
            <Boton titulo="Vincular Telegram" onPress={vincularTelegram} />
            <Boton titulo="Cambiar o desvincular dispositivo" tipo="secundario"
              onPress={desvincular} estilo={{ marginTop: 10 }} />
          </Tarjeta>
        </>
      )}

      <VincularModal
        visible={modalVincular}
        onCerrar={() => setModalVincular(false)}
        onConfirmar={confirmarVinculacion}
      />
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  contenido: { padding: 16, paddingBottom: 40 },
  cabecera: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 12 },
  logoCaja: { backgroundColor: '#fff', borderRadius: 10, padding: 4, borderBottomWidth: 3, borderBottomColor: colores.rojoMarca },
  logo: { width: 40, height: 46 },
  saludo: { color: colores.texto, fontSize: 18, fontWeight: '700' },
  dispositivo: { color: colores.textoSuave, fontSize: 13, marginTop: 2 },
  suave: { color: colores.textoSuave, fontSize: 14, marginBottom: 12 },
  fila: { flexDirection: 'row', gap: 10 },
  insignia: { color: '#fff', fontSize: 12, fontWeight: '700', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, overflow: 'hidden' },
  error: { color: colores.rojo, marginBottom: 12, fontSize: 13 },
});
