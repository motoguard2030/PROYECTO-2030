import React, { useState } from 'react';
import { ScrollView, Text, View, Image, StyleSheet, KeyboardAvoidingView, Platform, Pressable } from 'react-native';
import Boton from '../components/Boton';
import CampoTexto from '../components/CampoTexto';
import { useAuth } from '../context/AuthContext';
import { colores } from '../config/theme';

export default function LoginScreen({ irARegistro }) {
  const { iniciarSesion } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  async function ingresar() {
    setError('');
    if (!email.trim() || !password) {
      setError('Completá el correo y la contraseña.');
      return;
    }
    setCargando(true);
    try {
      await iniciarSesion(email, password);
    } catch (e) {
      setError(e.message);
      setCargando(false);
    }
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={estilos.contenido} keyboardShouldPersistTaps="handled">
        <View style={estilos.logoCaja}>
          <Image source={require('../../assets/logo.png')} style={estilos.logo} resizeMode="contain" />
        </View>
        <Text style={estilos.subtitulo}>Iniciá sesión para ver tu moto</Text>

        <CampoTexto etiqueta="Correo electrónico" value={email} onChangeText={setEmail}
          keyboardType="email-address" autoComplete="email" placeholder="correo@ejemplo.com" />
        <CampoTexto etiqueta="Contraseña" value={password} onChangeText={setPassword} secureTextEntry />

        {!!error && <Text style={estilos.error}>{error}</Text>}
        <Boton titulo="Ingresar" onPress={ingresar} cargando={cargando} />

        <Pressable onPress={irARegistro} style={{ marginTop: 20 }}>
          <Text style={estilos.enlace}>¿No tenés cuenta? Registrate</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const estilos = StyleSheet.create({
  contenido: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  logoCaja: { alignSelf: 'center', backgroundColor: '#fff', borderRadius: 20, padding: 12, borderBottomWidth: 4, borderBottomColor: colores.azul },
  logo: { width: 200, height: 230 },
  subtitulo: { color: colores.textoSuave, textAlign: 'center', marginBottom: 28, marginTop: 4 },
  error: { color: colores.rojo, marginBottom: 12, fontSize: 13 },
  enlace: { color: colores.azulClaro, textAlign: 'center', fontSize: 14 },
});
