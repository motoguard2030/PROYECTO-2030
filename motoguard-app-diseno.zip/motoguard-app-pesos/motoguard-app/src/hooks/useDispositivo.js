import { useEffect, useState } from 'react';
import api from '../services';

// Datos en vivo del dispositivo: { estado, activo, lat, lng, peso_min, peso_max, ... }
// `datos` es null hasta que llega el primer dato.
export function useDispositivo(codigo) {
  const [datos, setDatos] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    setDatos(null);
    setError(null);
    if (!codigo) return undefined;
    return api.suscribirDispositivo(codigo, setDatos, setError);
  }, [codigo]);

  return { datos, error };
}
