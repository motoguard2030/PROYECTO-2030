import { useEffect, useState } from 'react';
import api from '../services';

// Últimos eventos del dispositivo, el más reciente primero.
export function useHistorial(codigo) {
  const [eventos, setEventos] = useState([]);

  useEffect(() => {
    setEventos([]);
    if (!codigo) return undefined;
    return api.suscribirHistorial(codigo, setEventos);
  }, [codigo]);

  return eventos;
}
