import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import api from '../services';
import { guardarSesion, leerSesion, borrarSesion } from '../utils/session';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [cargando, setCargando] = useState(true);

  // Al abrir la app: si había una sesión guardada, la restauramos.
  useEffect(() => {
    (async () => {
      try {
        const clave = await leerSesion();
        if (clave) {
          const encontrado = await api.obtenerUsuario(clave);
          if (encontrado) setUsuario(encontrado);
        }
      } catch (e) {
        // sin conexión: queda en la pantalla de login
      } finally {
        setCargando(false);
      }
    })();
  }, []);

  const iniciarSesion = useCallback(async (email, password) => {
    const datos = await api.iniciarSesion(email, password);
    await guardarSesion(datos.clave);
    setUsuario(datos);
  }, []);

  const cerrarSesion = useCallback(async () => {
    await borrarSesion();
    setUsuario(null);
  }, []);

  // Para cuando cambia algo del usuario (por ejemplo, el dispositivo vinculado).
  const actualizarUsuario = useCallback((cambios) => {
    setUsuario((previo) => (previo ? { ...previo, ...cambios } : previo));
  }, []);

  return (
    <AuthContext.Provider value={{ usuario, cargando, iniciarSesion, cerrarSesion, actualizarUsuario }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
