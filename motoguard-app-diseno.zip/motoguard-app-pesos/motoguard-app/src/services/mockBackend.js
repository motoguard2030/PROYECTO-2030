// Backend SIMULADO, con las mismas funciones que firebaseBackend.js.
// Activarlo con BACKEND = 'mock' en config/constants.js.
// Sirve para ensayar la presentación sin hardware ni internet, y como
// ejemplo de cómo se reemplaza el backend sin tocar las pantallas.
//
// Dispositivo de prueba: MG-0001, PIN 1234.
import { REGEX_CODIGO, ESTADOS, POSICION_POR_DEFECTO } from '../config/constants';
import { claveDeEmail, normalizarCodigo, redondear1, gramosAKg } from '../utils/format';

const PINES = { 'MG-0001': '1234', 'MG-0002': '1234' };
const usuarios = {};
const dispositivos = {
  'MG-0001': { estado: ESTADOS.REPOSO, activo: true, ...POSICION_POR_DEFECTO, peso_min: 72, peso_max: 78, dueño: '' },
  'MG-0002': { estado: ESTADOS.REPOSO, activo: true, ...POSICION_POR_DEFECTO, peso_min: 72, peso_max: 78, dueño: '' },
};
const historiales = { 'MG-0001': [], 'MG-0002': [] };
const oyentes = { dispositivo: {}, historial: {} };

const pausa = (ms = 250) => new Promise((r) => setTimeout(r, ms));
const avisar = (tipo, codigo) => (oyentes[tipo][codigo] || []).forEach((f) => f());

function cambiarEstado(codigo, estado) {
  dispositivos[codigo].estado = estado;
  if (estado !== ESTADOS.REPOSO) {
    historiales[codigo].unshift({ id: String(Date.now()), estado, timestamp: Date.now() });
    avisar('historial', codigo);
  }
  avisar('dispositivo', codigo);
}

// Simula el ESP32: el GPS se mueve un poquito y cada ~20 s hay una "alerta".
let ciclo = 0;
setInterval(() => {
  ciclo += 1;
  Object.keys(dispositivos).forEach((codigo) => {
    const d = dispositivos[codigo];
    if (!d.dueño) return;
    d.lat += (Math.random() - 0.5) * 0.0002;
    d.lng += (Math.random() - 0.5) * 0.0002;
    if (d.comando === 'CALIBRAR') { delete d.comando; cambiarEstado(codigo, ESTADOS.REPOSO); return; }
    if (d.comando === 'TARA') delete d.comando;
    // Balanza simulada: oscila entre ~150 g y ~210 g.
    d.peso_actual = Math.round((150 + Math.random() * 60) * 10) / 10;
    const g = d.peso_actual / 1000;
    d.estado_peso = d.peso_min == null ? 'SIN_REGISTRO' : g < d.peso_min ? 'PESO_INSUFICIENTE' : g > d.peso_max ? 'PESO_EXCEDIDO' : 'AUTORIZADO';
    d.moto_encendida = d.estado_peso === 'AUTORIZADO';
    if (d.activo !== false) {
      if (ciclo % 7 === 0) cambiarEstado(codigo, ESTADOS.ALERTA);
      else if (ciclo % 7 === 1 && d.estado === ESTADOS.ALERTA) cambiarEstado(codigo, ESTADOS.CONFIRMADO);
      else if (ciclo % 7 === 4 && d.estado !== ESTADOS.REPOSO) cambiarEstado(codigo, ESTADOS.REPOSO);
    }
    avisar('dispositivo', codigo);
  });
}, 3000);

function suscribir(tipo, codigo, funcion) {
  oyentes[tipo][codigo] = [...(oyentes[tipo][codigo] || []), funcion];
  funcion();
  return () => { oyentes[tipo][codigo] = oyentes[tipo][codigo].filter((f) => f !== funcion); };
}

async function validar(codigo, pin, claveUsuario = '') {
  if (!REGEX_CODIGO.test(codigo)) throw new Error('El código tiene que ser MG- seguido de 4 números.');
  if (!pin) throw new Error('Falta el PIN de activación.');
  if (!PINES[codigo]) throw new Error('Código de dispositivo inválido.');
  if (PINES[codigo] !== pin) throw new Error('El PIN no coincide con ese código.');
  const dueno = dispositivos[codigo].dueño;
  if (dueno && dueno !== claveUsuario) throw new Error('Ese dispositivo ya está vinculado a otra cuenta.');
}

export async function verificarCodigo(codigoCrudo, claveUsuario = '') {
  await pausa(150);
  const codigo = normalizarCodigo(codigoCrudo);
  if (!REGEX_CODIGO.test(codigo)) return { estado: 'formato', mensaje: 'Formato: MG- seguido de 4 números.' };
  if (!PINES[codigo]) return { estado: 'inexistente', mensaje: 'Ese código no existe en el catálogo.' };
  const dueno = dispositivos[codigo].dueño;
  if (dueno && dueno !== claveUsuario) return { estado: 'ocupado', mensaje: 'Ese dispositivo ya está vinculado.' };
  return { estado: 'libre', mensaje: '✓ Código disponible.' };
}

export async function registrarUsuario({ nombre, email, password, codigo, pin, peso }) {
  await pausa();
  const codigoLimpio = normalizarCodigo(codigo);
  const clave = claveDeEmail(email);
  await validar(codigoLimpio, pin.trim());
  if (usuarios[clave]) throw new Error('Ese correo ya está registrado.');
  usuarios[clave] = { nombre, email: email.trim(), password, dispositivo: codigoLimpio };
  Object.assign(dispositivos[codigoLimpio], { dueño: clave, peso_min: redondear1(peso - 3), peso_max: redondear1(peso + 3) });
}

export async function iniciarSesion(email, password) {
  await pausa();
  const clave = claveDeEmail(email);
  if (!usuarios[clave]) throw new Error('Usuario no encontrado. ¿Te registraste?');
  if (usuarios[clave].password !== password) throw new Error('Contraseña incorrecta.');
  return { ...usuarios[clave], clave };
}

export async function obtenerUsuario(clave) {
  return usuarios[clave] ? { ...usuarios[clave], clave } : null;
}

export function suscribirDispositivo(codigo, alCambiar) {
  return suscribir('dispositivo', codigo, () => alCambiar({ ...dispositivos[codigo] }));
}

export function suscribirHistorial(codigo, alCambiar, limite = 10) {
  return suscribir('historial', codigo, () => alCambiar(historiales[codigo].slice(0, limite)));
}

export async function setActivo(codigo, activo) { dispositivos[codigo].activo = activo; avisar('dispositivo', codigo); }
export async function enviarCalibrar(codigo) { dispositivos[codigo].comando = 'CALIBRAR'; avisar('dispositivo', codigo); }
export async function guardarRangoPeso(codigo, min, max) {
  Object.assign(dispositivos[codigo], { peso_min: redondear1(min), peso_max: redondear1(max) });
  avisar('dispositivo', codigo);
}

export async function guardarPesoGramos(codigo, pesoG, toleranciaG) {
  Object.assign(dispositivos[codigo], { peso_min: gramosAKg(pesoG - toleranciaG), peso_max: gramosAKg(pesoG + toleranciaG) });
  avisar('dispositivo', codigo);
}
export async function enviarTara(codigo) { dispositivos[codigo].comando = 'TARA'; avisar('dispositivo', codigo); }

export async function desvincularDispositivo(usuario) {
  if (!usuario.dispositivo) return;
  dispositivos[usuario.dispositivo].dueño = '';
  usuarios[usuario.clave].dispositivo = '';
}

export async function vincularDispositivo(usuario, codigoCrudo, pinCrudo) {
  await pausa();
  const codigo = normalizarCodigo(codigoCrudo);
  await validar(codigo, pinCrudo.trim(), usuario.clave);
  if (usuario.dispositivo && usuario.dispositivo !== codigo) dispositivos[usuario.dispositivo].dueño = '';
  usuarios[usuario.clave].dispositivo = codigo;
  dispositivos[codigo].dueño = usuario.clave;
  return codigo;
}
