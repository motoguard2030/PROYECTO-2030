// Punto único de acceso a los datos. Las pantallas hacen:
//
//     import api from '../services';
//     api.iniciarSesion(email, password);
//
// y no saben si atrás hay Firebase, una API propia o datos simulados.
//
// Para usar tu API de Render: crear src/services/apiBackend.js que exporte las
// MISMAS funciones (mirá firebaseBackend.js como guía) y agregar un caso acá.
import { BACKEND } from '../config/constants';

let implementacion;
if (BACKEND === 'mock') {
  implementacion = require('./mockBackend');
} else {
  implementacion = require('./firebaseBackend');
}

export default implementacion;
