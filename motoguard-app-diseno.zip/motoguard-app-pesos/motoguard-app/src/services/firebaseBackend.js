// Implementación REAL: habla directo con Firebase Realtime Database.
//
// Es la única parte de la app que conoce Firebase. Las pantallas llaman a
// estas funciones a través de services/index.js. Si mañana los datos pasan
// por tu API de Render, se crea otro archivo con las MISMAS funciones y se
// cambia una línea en services/index.js.
//
// Modelo de datos (igual que la web):
//   MotoGuard/catalogo_dispositivos/{MG-0000}            -> PIN (texto)
//   MotoGuard/usuarios/{email_sanitizado}                -> {nombre,email,password,dispositivo,...}
//   MotoGuard/dispositivos/{MG-0000}/estado              -> REPOSO | ALERTA | MOVIMIENTO_CONFIRMADO
//   MotoGuard/dispositivos/{MG-0000}/{activo,lat,lng,comando,peso_min,peso_max,dueño,vinculado}
//   MotoGuard/dispositivos/{MG-0000}/{peso_actual,moto_encendida,estado_peso}   -> los escribe el ESP32 (balanza HX711)
//   MotoGuard/dispositivos/{MG-0000}/historial/{id}      -> {estado,timestamp}
import {
  ref, get, set, update, onValue, query, orderByChild, limitToLast,
} from 'firebase/database';
import { db } from '../config/firebase';
import { RAIZ, REGEX_CODIGO, HISTORIAL_MAXIMO } from '../config/constants';
import { claveDeEmail, normalizarCodigo, redondear1, gramosAKg } from '../utils/format';

const rutaDispositivo = (codigo) => `${RAIZ}/dispositivos/${codigo}`;
const rutaUsuario = (clave) => `${RAIZ}/usuarios/${clave}`;

async function leerDueno(codigo) {
  const snap = await get(ref(db, `${rutaDispositivo(codigo)}/dueño`));
  return snap.exists() && snap.val() ? snap.val() : '';
}

// Chequeo en vivo del código (para avisar mientras se escribe).
export async function verificarCodigo(codigoCrudo, claveUsuario = '') {
  const codigo = normalizarCodigo(codigoCrudo);
  if (!REGEX_CODIGO.test(codigo)) {
    return { estado: 'formato', mensaje: 'Formato: MG- seguido de 4 números (ej: MG-0007).' };
  }
  try {
    const catalogo = await get(ref(db, `${RAIZ}/catalogo_dispositivos/${codigo}`));
    if (!catalogo.exists()) {
      return { estado: 'inexistente', mensaje: 'Ese código no existe en el catálogo.' };
    }
    const dueno = await leerDueno(codigo);
    if (dueno && dueno !== claveUsuario) {
      return { estado: 'ocupado', mensaje: 'Ese dispositivo ya está vinculado a otra cuenta.' };
    }
    return { estado: 'libre', mensaje: '✓ Código disponible.' };
  } catch (e) {
    return { estado: 'error', mensaje: 'No se pudo verificar ahora.' };
  }
}

// Valida código + PIN + que esté libre. Lanza Error con un mensaje claro.
async function validarVinculacion(codigo, pin, claveUsuario = '') {
  if (!REGEX_CODIGO.test(codigo)) {
    throw new Error('El código tiene que ser MG- seguido de 4 números (ej: MG-0007).');
  }
  if (!pin) throw new Error('Falta el PIN de activación (viene en la etiqueta del dispositivo).');
  const catalogo = await get(ref(db, `${RAIZ}/catalogo_dispositivos/${codigo}`));
  if (!catalogo.exists()) throw new Error('Código de dispositivo inválido.');
  if (String(catalogo.val()) !== pin) throw new Error('El PIN no coincide con ese código.');
  const dueno = await leerDueno(codigo);
  if (dueno && dueno !== claveUsuario) throw new Error('Ese dispositivo ya está vinculado a otra cuenta.');
}

export async function registrarUsuario({ nombre, email, password, codigo, pin, peso }) {
  const codigoLimpio = normalizarCodigo(codigo);
  const pinLimpio = pin.trim();
  const clave = claveDeEmail(email);

  await validarVinculacion(codigoLimpio, pinLimpio);

  const existente = await get(ref(db, rutaUsuario(clave)));
  if (existente.exists()) throw new Error('Ese correo ya está registrado.');

  // Nota: la contraseña se guarda en texto plano para ser compatible con la web
  // y la app de App Inventor. Para producción: Firebase Authentication.
  await set(ref(db, rutaUsuario(clave)), {
    nombre,
    email: email.trim(),
    password,
    dispositivo: codigoLimpio,
    fechaCreacion: new Date().toISOString(),
  });
  await update(ref(db, rutaDispositivo(codigoLimpio)), {
    dueño: clave,
    vinculado: true,
    peso_min: redondear1(peso - 3),
    peso_max: redondear1(peso + 3),
  });
}

export async function iniciarSesion(email, password) {
  const clave = claveDeEmail(email);
  const snap = await get(ref(db, rutaUsuario(clave)));
  if (!snap.exists()) throw new Error('Usuario no encontrado. ¿Te registraste?');
  const datos = snap.val();
  if (datos.password !== password) throw new Error('Contraseña incorrecta.');
  return { ...datos, clave };
}

// Para restaurar la sesión guardada.
export async function obtenerUsuario(clave) {
  const snap = await get(ref(db, rutaUsuario(clave)));
  return snap.exists() ? { ...snap.val(), clave } : null;
}

// Escucha TODO el dispositivo en una sola conexión. Devuelve la función
// para dejar de escuchar.
export function suscribirDispositivo(codigo, alCambiar, alFallar) {
  return onValue(
    ref(db, rutaDispositivo(codigo)),
    (snap) => alCambiar(snap.val() || {}),
    (error) => alFallar && alFallar(error),
  );
}

// Últimos eventos, el más reciente primero.
export function suscribirHistorial(codigo, alCambiar, limite = HISTORIAL_MAXIMO) {
  const consulta = query(
    ref(db, `${rutaDispositivo(codigo)}/historial`),
    orderByChild('timestamp'),
    limitToLast(limite),
  );
  return onValue(consulta, (snap) => {
    const eventos = [];
    snap.forEach((hijo) => { eventos.push({ id: hijo.key, ...hijo.val() }); });
    alCambiar(eventos.reverse());
  });
}

export const setActivo = (codigo, activo) =>
  set(ref(db, `${rutaDispositivo(codigo)}/activo`), activo);

// El ESP32 revisa este campo y recalibra la posición de estacionamiento.
export const enviarCalibrar = (codigo) =>
  set(ref(db, `${rutaDispositivo(codigo)}/comando`), 'CALIBRAR');

export const guardarRangoPeso = (codigo, min, max) =>
  update(ref(db, rutaDispositivo(codigo)), { peso_min: redondear1(min), peso_max: redondear1(max) });

// Peso de prueba para la celda de carga, en GRAMOS. Se guarda en los mismos
// campos peso_min / peso_max (en kg) que ya lee el ESP32: 200 g ± 10 g ->
// peso_min 0.19 y peso_max 0.21.
export const guardarPesoGramos = (codigo, pesoG, toleranciaG) =>
  update(ref(db, rutaDispositivo(codigo)), {
    peso_min: gramosAKg(pesoG - toleranciaG),
    peso_max: gramosAKg(pesoG + toleranciaG),
  });

// El ESP32 pone la balanza en cero (usar con el asiento vacío).
export const enviarTara = (codigo) =>
  set(ref(db, rutaDispositivo(codigo) + '/comando'), 'TARA');

export async function desvincularDispositivo(usuario) {
  if (!usuario.dispositivo) return;
  await update(ref(db, rutaDispositivo(usuario.dispositivo)), { dueño: '', vinculado: false });
  await update(ref(db, rutaUsuario(usuario.clave)), { dispositivo: '' });
}

// Valida primero el nuevo; recién después libera el viejo (así no se queda
// sin dispositivo si el código o el PIN están mal). Devuelve el código nuevo.
export async function vincularDispositivo(usuario, codigoCrudo, pinCrudo) {
  const codigo = normalizarCodigo(codigoCrudo);
  const pin = pinCrudo.trim();
  await validarVinculacion(codigo, pin, usuario.clave);

  if (usuario.dispositivo && usuario.dispositivo !== codigo) {
    await update(ref(db, rutaDispositivo(usuario.dispositivo)), { dueño: '', vinculado: false });
  }
  await update(ref(db, rutaUsuario(usuario.clave)), { dispositivo: codigo });
  await update(ref(db, rutaDispositivo(codigo)), { dueño: usuario.clave, vinculado: true });
  return codigo;
}
