import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import Tarjeta from './Tarjeta';
import { colores } from '../config/theme';
import { POSICION_POR_DEFECTO } from '../config/constants';
import { esNumero } from '../utils/format';

// Mapa con Leaflet + OpenStreetMap dentro de un WebView (no necesita API key,
// igual que la web). El HTML se arma UNA vez; después solo se mueve el marcador.
function construirHtml(lat, lng) {
  return `<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>html,body,#map{height:100%;margin:0;padding:0}</style></head><body>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var map = L.map('map').setView([${lat}, ${lng}], 15);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
  {maxZoom: 19, attribution: '&copy; OpenStreetMap'}).addTo(map);
var marcador = L.circleMarker([${lat}, ${lng}],
  {radius: 9, color: '#ffffff', weight: 3, fillColor: '#E24B4A', fillOpacity: 1}).addTo(map);
function moverMarcador(a, b) { marcador.setLatLng([a, b]); map.panTo([a, b]); }
</script></body></html>`;
}

export default function MapaCard({ lat, lng }) {
  const hayGps = esNumero(lat) && esNumero(lng);
  const webRef = useRef(null);
  const [listo, setListo] = useState(false);

  // Posición inicial: se calcula una sola vez para no recargar el mapa.
  const html = useMemo(() => {
    const inicio = hayGps ? { lat, lng } : POSICION_POR_DEFECTO;
    return construirHtml(inicio.lat, inicio.lng);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (listo && hayGps && webRef.current) {
      webRef.current.injectJavaScript(`moverMarcador(${lat}, ${lng}); true;`);
    }
  }, [lat, lng, listo, hayGps]);

  return (
    <Tarjeta
      titulo="Ubicación en tiempo real"
      derecha={
        <Text style={estilos.coordenadas}>
          {hayGps ? `${lat.toFixed(4)}, ${lng.toFixed(4)}` : 'Esperando GPS...'}
        </Text>
      }
    >
      <View style={estilos.mapa}>
        <WebView
          ref={webRef}
          originWhitelist={['*']}
          source={{ html, baseUrl: 'https://motoguard-45eeb.firebaseapp.com' }}
          onLoadEnd={() => setListo(true)}
          scrollEnabled={false}
          nestedScrollEnabled
        />
      </View>
    </Tarjeta>
  );
}

const estilos = StyleSheet.create({
  mapa: { height: 240, borderRadius: 10, overflow: 'hidden', backgroundColor: colores.fondo },
  coordenadas: { color: colores.textoSuave, fontSize: 12 },
});
