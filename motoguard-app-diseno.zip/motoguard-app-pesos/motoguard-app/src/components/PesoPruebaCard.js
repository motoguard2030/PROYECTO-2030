import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import Tarjeta from './Tarjeta';
import Boton from './Boton';
import CampoTexto from './CampoTexto';
import { colores } from '../config/theme';
import { PESO_PRUEBA, ESTADOS_PESO, PESO_SIN_DATOS_MS } from '../config/constants';
import { esNumero, kgAGramos } from '../utils/format';

const num = (texto) => parseFloat(String(texto).replace(',', '.'));

// Qué mostrar según el estado_peso que publica el ESP32.
function resumen(motoEncendida, estadoPeso) {
  if (!estadoPeso) return { texto: 'Esperando datos de la balanza…', detalle: 'Si esto no cambia, el ESP32 no está publicando (revisá el monitor serie).', color: colores.textoSuave };
  if (estadoPeso === ESTADOS_PESO.INICIANDO) return { texto: 'Iniciando balanza…', detalle: 'Esperando las primeras lecturas.', color: colores.textoSuave };
  if (estadoPeso === ESTADOS_PESO.BALANZA_ERROR) return { texto: 'Balanza sin datos', detalle: 'El HX711 no responde. Revisá cables DT/SCK y alimentación. La moto queda bloqueada.', color: colores.ambar };
  if (motoEncendida) return { texto: 'Peso correcto: moto habilitada', detalle: 'El peso está dentro del rango autorizado.', color: colores.verde };
  const detalles = {
    [ESTADOS_PESO.INSUFICIENTE]: 'El peso es menor al autorizado.',
    [ESTADOS_PESO.EXCEDIDO]: 'El peso es mayor al autorizado.',
    [ESTADOS_PESO.SIN_REGISTRO]: 'Todavía no hay un peso guardado.',
    [ESTADOS_PESO.ASIENTO_VACIO]: 'El asiento está vacío.',
  };
  const incorrecto = estadoPeso === ESTADOS_PESO.INSUFICIENTE || estadoPeso === ESTADOS_PESO.EXCEDIDO;
  return { texto: incorrecto ? 'Peso incorrecto: moto NO enciende' : 'Moto NO enciende', detalle: detalles[estadoPeso] ?? '', color: colores.rojo };
}

// Prueba con la celda de carga: el usuario escribe el peso en gramos y la
// tolerancia, los guarda en Firebase y ve en vivo qué mide el ESP32.
export default function PesoPruebaCard({
  pesoMinKg, pesoMaxKg, pesoActualG, pesoTs, motoEncendida, estadoPeso, onGuardar, onTarar,
}) {
  const [peso, setPeso] = useState(String(PESO_PRUEBA.porDefecto));
  const [tolerancia, setTolerancia] = useState(String(PESO_PRUEBA.tolerancia));
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [esError, setEsError] = useState(false);
  const precargado = useRef(false);
  const [ahora, setAhora] = useState(Date.now());

  // Refresca cada 5 s para poder avisar si dejan de llegar lecturas.
  useEffect(() => {
    const id = setInterval(() => setAhora(Date.now()), 5000);
    return () => clearInterval(id);
  }, []);

  const hayRango = esNumero(pesoMinKg) && esNumero(pesoMaxKg);
  const minG = hayRango ? kgAGramos(pesoMinKg) : null;
  const maxG = hayRango ? kgAGramos(pesoMaxKg) : null;

  // Si ya hay un rango "de prueba" guardado (menos de 20 kg), lo trae a los
  // campos una sola vez. Un rango de conductor real (ej. 72–78 kg) no se toca.
  useEffect(() => {
    if (precargado.current || !hayRango) return;
    precargado.current = true;
    if (pesoMaxKg < 20) {
      setPeso(String((minG + maxG) / 2));
      setTolerancia(String((maxG - minG) / 2));
    }
  }, [hayRango, pesoMaxKg, minG, maxG]);

  async function guardar() {
    const pesoG = num(peso);
    const tolG = num(tolerancia);
    setEsError(true);
    if (!Number.isFinite(pesoG) || pesoG <= 0 || pesoG > PESO_PRUEBA.max) {
      setMensaje(`Ingresá un peso válido en gramos (1 a ${PESO_PRUEBA.max}).`);
      return;
    }
    if (!Number.isFinite(tolG) || tolG < PESO_PRUEBA.tolMin || tolG >= pesoG) {
      setMensaje(`La tolerancia tiene que ser de al menos ${PESO_PRUEBA.tolMin} g y menor al peso.`);
      return;
    }
    setGuardando(true);
    try {
      await onGuardar(pesoG, tolG);
      setEsError(false);
      setMensaje(`✓ Guardado: ${pesoG} g ± ${tolG} g (${pesoG - tolG} a ${pesoG + tolG} g).`);
    } catch (e) {
      setMensaje(`No se pudo guardar: ${e.message}`);
    } finally {
      setGuardando(false);
    }
  }

  const tarar = () => Alert.alert(
    'Tarar balanza',
    'El asiento tiene que estar VACÍO. La balanza va a tomar el peso actual como cero. ¿Continuar?',
    [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Tarar',
        onPress: async () => {
          try {
            await onTarar();
            Alert.alert('Listo', 'Comando enviado. En unos segundos la balanza queda en cero.');
          } catch (e) {
            Alert.alert('Error', e.message);
          }
        },
      },
    ],
  );

  const r = resumen(motoEncendida, estadoPeso);
  const edadMs = esNumero(pesoTs) ? ahora - pesoTs : null;
  const sinDatos = edadMs !== null && edadMs > PESO_SIN_DATOS_MS;

  return (
    <Tarjeta titulo="Peso del conductor (sensor)">
      <View style={[estilos.resultado, { borderColor: r.color }]}>
        <Text style={[estilos.resultadoTexto, { color: r.color }]}>{r.texto}</Text>
        {!!r.detalle && <Text style={estilos.suave}>{r.detalle}</Text>}
        <Text style={estilos.medido}>
          Peso medido: <Text style={estilos.valor}>{esNumero(pesoActualG) ? `${pesoActualG.toFixed(1)} g` : '—'}</Text>
        </Text>
        {esNumero(pesoTs) && (
          <Text style={[estilos.suave, sinDatos && { color: colores.ambar }]}>
            {sinDatos
              ? `Sin lecturas nuevas desde las ${new Date(pesoTs).toLocaleTimeString('es-AR')}`
              : `Última lectura: ${new Date(pesoTs).toLocaleTimeString('es-AR')}`}
          </Text>
        )}
        <Text style={estilos.suave}>
          Rango guardado: {hayRango ? `${minG} g – ${maxG} g` : 'ninguno todavía'}
        </Text>
      </View>

      <CampoTexto
        etiqueta="Peso del conductor (gramos)"
        value={peso}
        onChangeText={setPeso}
        keyboardType="decimal-pad"
        placeholder="200"
      />
      <CampoTexto
        etiqueta="Tolerancia ± (gramos)"
        value={tolerancia}
        onChangeText={setTolerancia}
        keyboardType="decimal-pad"
        placeholder="10"
      />

      <Boton titulo="Guardar peso en Firebase" onPress={guardar} cargando={guardando} />
      <Boton titulo="Tarar balanza (asiento vacío)" tipo="secundario" onPress={tarar} estilo={{ marginTop: 10 }} />

      {!!mensaje && (
        <Text style={[estilos.mensaje, { color: esError ? colores.rojo : colores.textoSuave }]}>{mensaje}</Text>
      )}
    </Tarjeta>
  );
}

const estilos = StyleSheet.create({
  resultado: { borderWidth: 1, borderRadius: 10, padding: 12, marginBottom: 16, backgroundColor: colores.fondo },
  resultadoTexto: { fontSize: 20, fontWeight: '700' },
  medido: { color: colores.textoSuave, fontSize: 13, marginTop: 8 },
  valor: { color: colores.texto, fontWeight: '700' },
  suave: { color: colores.textoSuave, fontSize: 13, marginTop: 4 },
  mensaje: { fontSize: 12, marginTop: 10 },
});
