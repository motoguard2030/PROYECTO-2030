import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ESTADOS } from '../config/constants';
import { colores } from '../config/theme';

// Cartel de aviso según el estado que manda el ESP32. En REPOSO no se muestra.
export default function AlertaBanner({ estado }) {
  if (estado === ESTADOS.CONFIRMADO) {
    return (
      <View style={[estilos.caja, { backgroundColor: colores.rojo }]}>
        <Text style={estilos.texto}>🚨 ¡ALERTA! Se confirmó movimiento sospechoso en tu moto.</Text>
      </View>
    );
  }
  if (estado === ESTADOS.ALERTA) {
    return (
      <View style={[estilos.caja, { backgroundColor: colores.ambar }]}>
        <Text style={estilos.texto}>⚠️ Se detectó movimiento en tu moto. Estamos confirmando.</Text>
      </View>
    );
  }
  return null;
}

const estilos = StyleSheet.create({
  caja: { borderRadius: 12, padding: 14, marginBottom: 16 },
  texto: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
