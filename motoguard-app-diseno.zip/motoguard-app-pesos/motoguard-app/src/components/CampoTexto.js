import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { colores } from '../config/theme';

// `ayuda` es un texto chico debajo del campo; `tonoAyuda` = 'ok' | 'error' | undefined.
export default function CampoTexto({ etiqueta, ayuda, tonoAyuda, ...resto }) {
  const colorAyuda = tonoAyuda === 'ok' ? colores.verde : tonoAyuda === 'error' ? colores.rojo : colores.textoSuave;
  return (
    <View style={estilos.contenedor}>
      <Text style={estilos.etiqueta}>{etiqueta}</Text>
      <TextInput
        placeholderTextColor={colores.textoSuave}
        autoCapitalize="none"
        style={[
          estilos.input,
          tonoAyuda === 'error' && { borderColor: colores.rojo },
          tonoAyuda === 'ok' && { borderColor: colores.verde },
        ]}
        {...resto}
      />
      {!!ayuda && <Text style={[estilos.ayuda, { color: colorAyuda }]}>{ayuda}</Text>}
    </View>
  );
}

const estilos = StyleSheet.create({
  contenedor: { marginBottom: 14 },
  etiqueta: { color: colores.textoSuave, fontSize: 13, marginBottom: 6 },
  input: {
    backgroundColor: colores.fondo,
    borderColor: colores.borde,
    borderWidth: 1,
    borderRadius: 10,
    color: colores.texto,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
  },
  ayuda: { fontSize: 12, marginTop: 4 },
});
