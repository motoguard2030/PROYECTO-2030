import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ESTADOS_PESO } from '../config/constants';
import { colores } from '../config/theme';
import { esNumero } from '../utils/format';

// Cartel de aviso según el estado_peso que publica el ESP32.
//   AUTORIZADO               -> peso correcto, la moto puede encender.
//   PESO_INSUFICIENTE/EXCEDIDO -> peso incorrecto, la moto NO enciende.
//   BALANZA_ERROR            -> la balanza no responde (la moto queda bloqueada).
// Con asiento vacío, sin rango o iniciando no se muestra nada.
export default function PesoBanner({ estadoPeso, pesoActualG }) {
  const peso = esNumero(pesoActualG) ? `${pesoActualG.toFixed(1)} g` : '';

  if (estadoPeso === ESTADOS_PESO.AUTORIZADO) {
    return (
      <View style={[estilos.caja, { backgroundColor: colores.verde }]}>
        <Text style={estilos.texto}>✅ Peso correcto{peso ? ` (${peso})` : ''}: la moto está habilitada para encender.</Text>
      </View>
    );
  }
  if (estadoPeso === ESTADOS_PESO.INSUFICIENTE || estadoPeso === ESTADOS_PESO.EXCEDIDO) {
    const detalle = estadoPeso === ESTADOS_PESO.EXCEDIDO ? 'supera el máximo autorizado' : 'es menor al mínimo autorizado';
    return (
      <View style={[estilos.caja, { backgroundColor: colores.rojo }]}>
        <Text style={estilos.texto}>🚫 Peso incorrecto{peso ? ` (${peso})` : ''}: {detalle}. La moto NO enciende.</Text>
      </View>
    );
  }
  if (estadoPeso === ESTADOS_PESO.BALANZA_ERROR) {
    return (
      <View style={[estilos.caja, { backgroundColor: colores.ambar }]}>
        <Text style={estilos.texto}>⚠️ La balanza no responde. La moto queda bloqueada hasta que vuelva a leer.</Text>
      </View>
    );
  }
  return null;
}

const estilos = StyleSheet.create({
  caja: { borderRadius: 12, padding: 14, marginBottom: 16 },
  texto: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
