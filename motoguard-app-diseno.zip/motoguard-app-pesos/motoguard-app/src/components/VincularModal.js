import React, { useState } from 'react';
import { Modal, View, Text, StyleSheet } from 'react-native';
import Boton from './Boton';
import CampoTexto from './CampoTexto';
import { colores } from '../config/theme';

// Ventana para vincular un dispositivo nuevo (código + PIN de la etiqueta).
// (Alert.prompt existe solo en iOS, por eso se usa un Modal propio.)
export default function VincularModal({ visible, onCerrar, onConfirmar }) {
  const [codigo, setCodigo] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  function cerrar() {
    setCodigo(''); setPin(''); setError('');
    onCerrar();
  }

  async function confirmar() {
    setError('');
    setCargando(true);
    try {
      await onConfirmar(codigo, pin);
      cerrar();
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  }

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={cerrar}>
      <View style={estilos.fondo}>
        <View style={estilos.caja}>
          <Text style={estilos.titulo}>Vincular dispositivo</Text>
          <CampoTexto etiqueta="Código (ej: MG-0007)" value={codigo} onChangeText={setCodigo} autoCapitalize="characters" />
          <CampoTexto etiqueta="PIN de activación" value={pin} onChangeText={setPin} secureTextEntry keyboardType="number-pad" />
          {!!error && <Text style={estilos.error}>{error}</Text>}
          <Boton titulo="Vincular" onPress={confirmar} cargando={cargando} />
          <Boton titulo="Cancelar" tipo="secundario" onPress={cerrar} estilo={{ marginTop: 8 }} />
        </View>
      </View>
    </Modal>
  );
}

const estilos = StyleSheet.create({
  fondo: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 24 },
  caja: { backgroundColor: colores.tarjeta, borderRadius: 14, padding: 20, borderWidth: 1, borderColor: colores.borde },
  titulo: { color: colores.texto, fontSize: 18, fontWeight: '700', marginBottom: 16 },
  error: { color: colores.rojo, fontSize: 13, marginBottom: 12 },
});
