import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Tarjeta from './Tarjeta';
import { colores } from '../config/theme';
import { ESTADOS, EVENTO_PESO_INCORRECTO } from '../config/constants';
import { formatearFecha } from '../utils/format';

export default function HistorialCard({ eventos }) {
  return (
    <Tarjeta titulo="Historial de alertas">
      {eventos.length === 0 ? (
        <Text style={estilos.vacio}>Todavía no hay eventos registrados.</Text>
      ) : (
        eventos.map((evento) => {
          const confirmado = evento.estado === ESTADOS.CONFIRMADO;
          const pesoIncorrecto = evento.estado === EVENTO_PESO_INCORRECTO;
          const icono = pesoIncorrecto ? '⚖️' : confirmado ? '🚨' : '⚠️';
          const titulo = pesoIncorrecto
            ? `Peso no autorizado${typeof evento.peso === 'number' ? ` (${evento.peso.toFixed(1)} g)` : ''} - la moto no enciende`
            : confirmado ? 'Movimiento sospechoso confirmado' : 'Movimiento detectado';
          return (
            <View key={evento.id} style={estilos.fila}>
              <Text style={estilos.icono}>{icono}</Text>
              <View style={{ flex: 1 }}>
                <Text style={estilos.titulo}>{titulo}</Text>
                <Text style={estilos.fecha}>{formatearFecha(evento.timestamp)}</Text>
              </View>
            </View>
          );
        })
      )}
    </Tarjeta>
  );
}

const estilos = StyleSheet.create({
  vacio: { color: colores.textoSuave, fontSize: 14 },
  fila: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderTopWidth: 1, borderTopColor: colores.borde },
  icono: { fontSize: 22, marginRight: 12 },
  titulo: { color: colores.texto, fontSize: 14, fontWeight: '600' },
  fecha: { color: colores.textoSuave, fontSize: 12, marginTop: 2 },
});
