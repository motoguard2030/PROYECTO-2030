import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colores, espaciado } from '../config/theme';

export default function Tarjeta({ titulo, derecha, children }) {
  return (
    <View style={estilos.tarjeta}>
      {(titulo || derecha) && (
        <View style={estilos.cabecera}>
          <Text style={estilos.titulo}>{titulo}</Text>
          {derecha}
        </View>
      )}
      {children}
    </View>
  );
}

const estilos = StyleSheet.create({
  tarjeta: {
    backgroundColor: colores.tarjeta,
    borderColor: colores.borde,
    borderWidth: 1,
    borderRadius: 14,
    padding: espaciado.l,
    marginBottom: espaciado.l,
  },
  cabecera: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: espaciado.m },
  titulo: { color: colores.texto, fontSize: 16, fontWeight: '700' },
});
